import express from 'express';
import { WebSocketServer } from 'ws';
import http from 'http';

const app = express();
app.use(express.static('public'));
const server = http.createServer(app);
const wss = new WebSocketServer({ server });
const rooms = new Map();

wss.on('connection', ws => {
  let room = null;
  ws.on('message', raw => {
    let msg; try { msg = JSON.parse(raw); } catch { return; }
    if (msg.type === 'join') {
      room = String(msg.room || '').trim();
      if (!room) return;
      if (!rooms.has(room)) rooms.set(room, new Set());
      const peers = rooms.get(room);
      for (const p of peers) if (p.readyState === 1) p.send(JSON.stringify({type:'peer-joined'}));
      peers.add(ws);
      ws.send(JSON.stringify({type:'joined', count: peers.size}));
    } else if (room && rooms.has(room)) {
      for (const p of rooms.get(room)) if (p !== ws && p.readyState === 1) p.send(raw.toString());
    }
  });
  ws.on('close', () => {
    if (!room || !rooms.has(room)) return;
    const peers = rooms.get(room); peers.delete(ws);
    for (const p of peers) if (p.readyState === 1) p.send(JSON.stringify({type:'peer-left'}));
    if (!peers.size) rooms.delete(room);
  });
});

const port = process.env.PORT || 3000;
server.listen(port, () => console.log(`GLOBAL 804 running on http://localhost:${port}`));
